# 📖 Book Review Site 

# Objective
Create a review site that will contains a list of reviews using headless CMS and frontend parts.

#### Team Members:
Kirandeep Kaur <br>
Ravinderpal Sharma
  
### Review Site Type
Book Review

### Frameworks and Tools Used
- Headless CMS: Strapi / Render / PostgreSQL / Neon / Cloudinary
- Frontend: Nuxt / Netlify
- JS: VueJS
- CSS & Components: Bootstrap / Nuxt Rating
