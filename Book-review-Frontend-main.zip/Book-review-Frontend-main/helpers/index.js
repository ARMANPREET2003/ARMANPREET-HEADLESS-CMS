const BASE_URL = 'https://review-site-headless-cms.onrender.com/api/reviews/'
const POPULATE_URL = '?populate=image'
const API_URL = BASE_URL + POPULATE_URL

export { BASE_URL, POPULATE_URL, API_URL }